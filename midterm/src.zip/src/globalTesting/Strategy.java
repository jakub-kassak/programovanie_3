package globalTesting;

import java.util.List;

public interface Strategy {
    void addPersonnel(List<Unit> units, int count);
}
