package globalTesting;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MostCompleteByOne implements Strategy{
    @Override
    public void addPersonnel(List<Unit> units, int count) {
        List<Unit> list = units;
        for (int i = 0; i < count; i++) {
            list = list.stream().filter(x -> x.freePositions() > 0).toList();

            int ft = Integer.MAX_VALUE;
            Unit u_max = null;
            for (Unit u : list){
                if (u.totalTeamsCount() - u.filledTeamsCount() < ft) {
                    u_max = u;
                    ft = u.totalTeamsCount() - u.filledTeamsCount();
                }
            }
            u_max.addPersonell(1);
        }

    }
}
